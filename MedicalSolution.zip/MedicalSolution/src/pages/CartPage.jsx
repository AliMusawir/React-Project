// src/pages/CartPage.js
import React from 'react';

const CartPage = () => {
  return <h1>Cart Page</h1>;
};

export default CartPage;
