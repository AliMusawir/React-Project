// src/pages/HomePage.js
import React from 'react';

const HomePage = () => {
  return <h1>Home Page</h1>;
};

export default HomePage;
