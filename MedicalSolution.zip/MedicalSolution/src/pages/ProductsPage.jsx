    // src/pages/ProductsPage.js
import React from 'react';

const ProductsPage = () => {
  return <h1>Products Page</h1>;
};

export default ProductsPage;
